// UI Elements
const statusMessage = document.getElementById("status-message");
const statusIcon = document.getElementById("status-icon");
const sitemapChecker = document.getElementById("sitemap-checker");
const sitemapUrlInput = document.getElementById("sitemap-url");
const checkDuplicatesBtn = document.getElementById("check-duplicates");
const resultsContainer = document.getElementById("results-container");
const resultsDiv = document.getElementById("results");
const duplicateCountSpan = document.getElementById("duplicate-count");
const copyResultsBtn = document.getElementById("copy-results");

// Google Analytics Measurement ID
const GA_MEASUREMENT_ID = "G-G-N04DBJ7TDV"; 

document.addEventListener("DOMContentLoaded", () => {
    updateStatus("Ready to check sitemaps", "success");
    
    // Show sitemap checker immediately (no auth required)
    sitemapChecker.style.display = "block";
});

// Update status message
function updateStatus(message, type) {
    statusMessage.textContent = message;
    statusIcon.className = "status-icon " + type;
}

// Check for duplicate links in sitemap
checkDuplicatesBtn.addEventListener("click", async () => {
    const sitemapUrl = sitemapUrlInput.value.trim();
    
    if (!sitemapUrl) {
        updateStatus("Please enter a sitemap URL", "error");
        return;
    }
    
    if (!sitemapUrl.endsWith('.xml') && !sitemapUrl.includes('sitemap')) {
        updateStatus("URL doesn't appear to be a sitemap", "error");
        return;
    }
    
    updateStatus("Checking for duplicates...", "loading");
    resultsContainer.style.display = "none";
    
    try {
        // Track sitemap check
        trackEvent("check_sitemap", { url: sitemapUrl });
        
        const response = await fetch(sitemapUrl);
        const text = await response.text();
        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(text, "text/xml");
        const urls = xmlDoc.getElementsByTagName("loc");
        
        const urlList = [];
        for (let i = 0; i < urls.length; i++) {
            urlList.push(urls[i].textContent);
        }
        
        const duplicates = findDuplicates(urlList);
        displayResults(duplicates);
        
        updateStatus(`Found ${duplicates.length} duplicate URLs`, 
                    duplicates.length > 0 ? "error" : "success");
        
        // Track results
        trackEvent("found_duplicates", { 
            url: sitemapUrl, 
            count: duplicates.length 
        });
    } catch (error) {
        console.error("Error fetching sitemap:", error);
        updateStatus("Error fetching sitemap. Check URL and try again.", "error");
        
        // Track error
        trackEvent("error", { 
            type: "fetch_sitemap", 
            message: error.message 
        });
    }
});

// Find duplicate URLs
function findDuplicates(urls) {
    const seen = new Set();
    const duplicates = [];
    
    for (const url of urls) {
        if (seen.has(url)) {
            duplicates.push(url);
        } else {
            seen.add(url);
        }
    }
    
    return duplicates;
}

// Display results
function displayResults(duplicates) {
    resultsDiv.innerHTML = "";
    duplicateCountSpan.textContent = duplicates.length;
    
    if (duplicates.length === 0) {
        resultsDiv.innerHTML = '<div class="no-duplicates">No duplicate URLs found!</div>';
        copyResultsBtn.disabled = true;
    } else {
        duplicates.forEach(url => {
            const div = document.createElement("div");
            div.className = "result-item";
            div.textContent = url;
            resultsDiv.appendChild(div);
        });
        copyResultsBtn.disabled = false;
    }
    
    resultsContainer.style.display = "block";
}

// Copy results to clipboard
copyResultsBtn.addEventListener("click", () => {
    const duplicateUrls = Array.from(resultsDiv.querySelectorAll(".result-item"))
        .map(div => div.textContent)
        .join("\n");
    
    navigator.clipboard.writeText(duplicateUrls).then(() => {
        const originalText = copyResultsBtn.textContent;
        copyResultsBtn.textContent = "Copied!";
        setTimeout(() => {
            copyResultsBtn.textContent = originalText;
        }, 2000);
        
        // Track copy action
        trackEvent("copy_results", { count: duplicateUrls.split("\n").length });
    });
});

// Track events to Google Analytics
function trackEvent(eventName, params = {}) {
    // Log to console for debugging
    console.log(`EVENT: ${eventName}`, params);
    
    // Send to Google Analytics 4 using the Measurement Protocol
    const analyticsData = {
        client_id: getOrCreateClientId(),
        events: [{
            name: eventName,
            params: params
        }]
    };

    // Using fetch to send data to GA4 Measurement Protocol
    fetch(`https://www.google-analytics.com/mp/collect?measurement_id=${GA_MEASUREMENT_ID}&api_secret=bUQSkT_oS6qOPj61-2Q0fA`, {
        method: 'POST',
        body: JSON.stringify(analyticsData)
    }).catch(error => console.error("Analytics error:", error));
}

// Generate or retrieve client ID for analytics
function getOrCreateClientId() {
    let clientId = localStorage.getItem('ga_client_id');
    if (!clientId) {
        clientId = Math.random().toString(36).substring(2) + '.' + Date.now();
        localStorage.setItem('ga_client_id', clientId);
    }
    return clientId;
}